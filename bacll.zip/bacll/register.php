<?php
session_start();
require_once 'db.php';

$message = '';

if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $password);

    if ($stmt->execute()) {
        header("Location: login.php");
        exit();
    } else {
        $message = "Username នេះមានរួចហើយ!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register - BaC System</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f2f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: #ffc0cb; padding: 30px; border-radius: 8px; text-align: center; width: 320px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        input { width: 90%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 4px; }
        button { padding: 10px 20px; margin: 5px; border: 1px solid #ccc; border-radius: 4px; background: #fff; cursor: pointer; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Form Register</h2>
        <p>Enter Username and Password</p>
        <?php if($message) echo "<p style='color:red;'>$message</p>"; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="username" required><br>
            <input type="password" name="password" placeholder="password" required><br>
            <button type="submit" name="register">Register</button>
            <a href="login.php"><button type="button">Back to Login</button></a>
        </form>
    </div>
</body>
</html>


