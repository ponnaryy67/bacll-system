<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .header { background: #2563eb; color: white; text-align: center; padding: 40px 20px; }
        .header h1 { margin: 0; font-size: 26px; }
        .header p { margin: 8px 0; font-size: 13px; opacity: 0.9; }
        .badge { background: #1e40af; display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 11px; margin-bottom: 15px; }
        .btn-logout { background: white; color: black; border: none; padding: 6px 14px; border-radius: 4px; font-weight: bold; cursor: pointer; text-decoration: none; }
        .btn-view { background: #10b981; color: white; border: none; padding: 6px 14px; border-radius: 4px; font-weight: bold; cursor: pointer; text-decoration: none; margin-left: 6px; }
        
        .container { display: flex; justify-content: center; gap: 20px; margin-top: 30px; }
        
        /* ធ្វើឱ្យ link គ្របដណ្តប់លើ card ទាំងមូល */
        .card-link { text-decoration: none; transition: transform 0.2s ease; }
        .card-link:hover { transform: translateY(-5px); }

        .card-blue { background: #2563eb; color: white; width: 260px; padding: 25px; border-radius: 8px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .card-orange { background: #d97706; color: white; width: 260px; padding: 25px; border-radius: 8px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .card-title { font-weight: bold; font-size: 16px; margin-bottom: 6px; }
        .card-sub { font-size: 12px; opacity: 0.85; }
    </style>
</head>
<body>

    <div class="header">
        <h1>Student Dashboard</h1>
        <p>Choose a class track to calculate grades.</p>
        <div class="badge">
            Joined by <b><?= htmlspecialchars($_SESSION['username']); ?></b> on <?= $_SESSION['joined_at']; ?>
        </div>
        <div>
            <a href="logout.php" class="btn-logout">Logout</a>
            <a href="student_list.php" class="btn-view">View User Data</a>
        </div>
    </div>

    <div class="container">
        <!-- science_form.php link -->
        <a href="science_form.php" class="card-link">
            <div class="card-blue">
                <div class="card-title">Science Class Track</div>
                <div class="card-sub">Math, Biology, Chemistry, Physics</div>
            </div>
        </a>

        <!-- social_form.php link -->
        <a href="social_form.php" class="card-link">
            <div class="card-orange">
                <div class="card-title">Social Class Track</div>
                <div class="card-sub">Khmer, History, Geography, Civics</div>
            </div>
        </a>
    </div>

</body>
</html>


